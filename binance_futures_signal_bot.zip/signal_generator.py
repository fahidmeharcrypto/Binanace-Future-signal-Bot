def generate_signals():
    return [
        {"pair": "BTC/USDT", "direction": "Long", "entry": "64000", "stop_loss": "63000", "take_profit": "66000"},
        {"pair": "ETH/USDT", "direction": "Short", "entry": "3200", "stop_loss": "3300", "take_profit": "3000"},
    ]
