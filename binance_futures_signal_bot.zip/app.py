from flask import Flask, render_template
from signal_generator import generate_signals

app = Flask(__name__)

@app.route("/")
def home():
    signals = generate_signals()
    return render_template("index.html", signals=signals)

if __name__ == "__main__":
    app.run(debug=True)
