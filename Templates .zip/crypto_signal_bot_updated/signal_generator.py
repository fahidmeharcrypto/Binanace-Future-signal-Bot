def get_signal():
    return {
        "pair": "BTC/USDT",
        "direction": "long",
        "entry": "50000",
        "stop_loss": "49500",
        "take_profit": "51000"
    }
